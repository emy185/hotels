import { useState } from "react";
import SearchBar from 'src/components/SearchBar';
import PopularActivities from 'src/components/PopularActivities';
import whyChooseTourz from 'src/components/whyChooseTourz.js';
import "./App.css";

function App() {
  const [count, setCount] = useState(0);

  return (
    <div>
    <header/>
     <SearchBar />
      <PopularActivities />
      <WhyChooseTourz />
    <footer/>
    </div>
  );
}

export default App;
