import React from "react";
import "./LoginForm.css";

function LoginForm() {
  return (
    <div className="login-form">
      <h1>Log In</h1>
      <p>
        We're glad to see you again! <a href="#">Sign Up</a>
      </p>
      <form>
        <label htmlFor="email">Email Address</label>
        <input type="email" id="email" placeholder="Email Address" required />

        <label htmlFor="password">Password</label>
        <input type="password" id="password" placeholder="Password" required />

        <div className="remember-me">
          <input type="checkbox" id="remember" />
          <label htmlFor="remember">Remember me</label>
          <a href="#">Lost your password?</a>
        </div>

        <button type="submit" className="login-button">
          Log In
        </button>
      </form>

      <p>OR</p>

      <div className="social-login">
        <button>Continue with Facebook</button>
        <button>Continue with Google</button>
      </div>
    </div>
  );
}

export default LoginForm;
