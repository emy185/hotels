import React from "react";
import cruiseImage from "src/images/1 (1).jpg";
import beachImage from "src/images/1 (2).jpg";
import cityImage from "src/images/3 (1).jpg";
import museumImage from "src/images/4 (1).jpg";
import foodImage from "src/images/5.jpg";
import hikingImage from "src/images/6.jpg";

const activities = [
  { title: "Cruises", image: cruiseImage },
  { title: "Beach Tours", image: beachImage },
  { title: "City Tours", image: cityImage },
  { title: "Museum Tour", image: museumImage },
  { title: "Food", image: foodImage },
  { title: "Hiking", image: hikingImage },
];

const PopularActivities = () => {
  return (
    <div className="popular-activities">
      <h2>Popular Things to Do</h2>
      <div className="activities-grid">
        {activities.map((activity, index) => (
          <div key={index} className="activity-card">
            <img src={activity.image} alt={activity.title} />
            <h3>{activity.title}</h3>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PopularActivities;
