import React from "react";

const benefits = [
  {
    icon: "src/images/ticket.svg", 
    title: "Ultimate flexibility",
    description:
      "You're in control, with free cancellation and payment options to satisfy any plan or budget.",
  },
  {
    icon: "src/images/hot-air-balloon.svg",
    title: "Memorable experiences",
    description:
      "Browse and book tours and activities so incredible, you'll want to tell your friends.",
  },
  {
    icon: "src/images/diamond.svg",
    title: "Quality at our core",
    description:
      "High-quality standards. Millions of reviews. A tourz company.",
  },
  {
    icon: "src/images/medal.svg",
    title: "Award-winning support",
    description: "New price? New plan? No problem. We're here to help, 24/7.",
  },
];

const WhyChooseTourz = () => {
  return (
    <div className="why-choose-tourz">
      <h2>Why choose Tourz</h2>
      <div className="benefits-grid">
        {benefits.map((benefit, index) => (
          <div key={index} className="benefit-card">
            <div className="icon">{benefit.icon}</div>
            <h3>{benefit.title}</h3>
            <p>{benefit.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default WhyChooseTourz;
