import React, { useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const SearchBar = () => {
  const [startDate, setStartDate] = useState(new Date());

  return (
    <div className="search-bar">
      <input type="text" placeholder="Where" className="search-input" />
      <DatePicker
        selected={startDate}
        onChange={(date) => setStartDate(date)}
        className="date-picker"
        placeholderText="When"
      />
      <select className="tour-type">
        <option value="all">Tour Type</option>
        <option value="beach">Beach Tours</option>
        <option value="city">City Tours</option>
      </select>
      <button className="search-button">Search</button>
    </div>
  );
};

export default SearchBar;
